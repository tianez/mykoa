'use strict'

var ApiCloudsIndex = React.createClass({
    render: function() {
        return (
            React.createElement('a', {
                    className: 'pure-menu-heading pure-menu-link left'
                },
                'ApiCloudsIndex'
            )
        );
    }
})

module.exports = ApiCloudsIndex
