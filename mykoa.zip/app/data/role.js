module.exports = [{
    key: 'admin',
    name: '管理员',
    thumb: '',
    description: '系统管理员',
    status: 0
}, {
    key: 'editor',
    name: '编辑',
    thumb: '',
    description: '编辑',
    status: 0
}, {
    key: 'reader',
    name: '读者',
    thumb: '',
    description: '普通用户',
    status: 0
}]