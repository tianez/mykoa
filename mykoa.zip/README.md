# mykoa
mykoa

sequelize-auto -o app/models -d koa -u root -x 123456 -h localhost
